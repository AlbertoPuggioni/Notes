CREATE TABLE Testo (
    id_testo INT PRIMARY KEY,
    Titolo LONGTEXT NOT NULL
);

CREATE TABLE Paragrafo (
    id_paragrafo INT PRIMARY KEY,
    id_testo INT NOT NULL,
    FOREIGN KEY (id_testo) REFERENCES Testo(id_testo)
);

CREATE TABLE Frase (
    id_frase INT PRIMARY KEY,
    id_paragrafo INT NOT NULL,
    testo LONGTEXT NOT NULL,
    FOREIGN KEY (id_paragrafo) REFERENCES Paragrafo (id_paragrafo)
);

CREATE TABLE Parola (
    id_parola INT PRIMARY KEY,
    id_frase INT NOT NULL,
    testo LONGTEXT NOT NULL,
    FOREIGN KEY (id_frase) REFERENCES Frase (id_frase)
);

INSERT INTO Testo (Titolo)
VALUES ("Aldo Romeo Luigi Moro (Maglie, 23 settembre 1916 – Roma, 9 maggio 1978) è stato un politico e giurista italiano.

Tra i fondatori della Democrazia Cristiana e suo rappresentante nella Costituente, ne divenne dapprima Segretario dal 1959 al 1964 e in seguito Presidente nel 1976; all'interno del partito aderí inizialmente alla corrente dorotea, ma negli anni 1960 assunse una posizione più indipendente formando la corrente morotea. Fu Ministro della giustizia (1955-1957), della Pubblica istruzione (1957-1959) e per quattro volte Ministro degli esteri (1969-1972 e 1973-1974) nei governi presieduti da Mariano Rumor ed Emilio Colombo. Cinque volte Presidente del Consiglio dei ministri, guidò governi di centro-sinistra 'organico' tra il 1963 e il 1968 e tra il 1974 e il 1976 promuovendo la cosiddetta strategia dell'attenzione verso il Partito Comunista Italiano attraverso il compromesso storico[1] e determinò la nascita del Governo Andreotti III (definito il governo della non-sfiducia) in cui il PCI garantiva l'astensione.");

