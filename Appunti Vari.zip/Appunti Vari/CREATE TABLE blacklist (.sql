CREATE TABLE blacklist (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    parola TEXT NULL,
    conteggio_parola INT NULL
    id_testo INTEGER (11) NULL
    FOREIGN KEY (id_testo) REFERENCES testo(id_testo)
);

CREATE TABLE punteggiatura (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    simbolo TEXT NOT NULL,
    id_testo INTEGER,
    FOREIGN KEY (id_testo) REFERENCES testo(id_testo)
);

INSERT INTO blacklist (id,parola,conteggio_parola) VALUES (3,'parola1');
INSERT INTO blacklist (id,parola,conteggio_parola) VALUES (3,'parola2');
INSERT INTO blacklist (id,parola,conteggio_parola) VALUES (3,'parola3');

INSERT INTO punctuation (simbolo) VALUES (',');
INSERT INTO punctuation (simbolo) VALUES ('.');
INSERT INTO punctuation (simbolo) VALUES ('!');

